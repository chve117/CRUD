package paquete;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;


public class NewServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
         String ruta=request.getRealPath("/");                
         response.addHeader("Access-Control-Allow-Origin", "*"); 
         response.setContentType("application/json");
         response.setCharacterEncoding("UTF-8");
         PrintWriter out = response.getWriter();            
         try{
         SAXBuilder builder = new SAXBuilder();     
         File xmlFile = new File(ruta+"cuestionario.xml");                
         Document doc = builder.build(xmlFile);
         Element rootNode = doc.getRootElement();
         List list = rootNode.getChildren("pregunta");
         Element Pregunta=new Element("pregunta");
         Pregunta.setAttribute("numeroPregunta",""+(list.size()+1));
         Element option=new Element("option");
         for(int j=0;j<5;j++){
             Element node = new Element("opcion");
             node.setText(request.getParameter("opcion"+j));
             option.addContent(node);
         }
         Pregunta.addContent(option);
         Pregunta.setAttribute("pregunta",request.getParameter("pregunta"));
         Pregunta.setAttribute("respuesta",request.getParameter("respuesta"));
         rootNode.addContent(Pregunta);
         XMLOutputter xmlOutput = new XMLOutputter();
         xmlOutput.setFormat(Format.getPrettyFormat());
         FileOutputStream writer = new FileOutputStream(ruta+"cuestionario.xml");                
         xmlOutput.output(doc, writer);
         writer.flush();
         writer.close();
         }
         catch (IOException | JDOMException e) 
         {
         e.printStackTrace();
         }
    }
}