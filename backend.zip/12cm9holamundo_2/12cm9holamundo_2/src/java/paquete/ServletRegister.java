package paquete;

import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class ServletRegister extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
          response.addHeader("Access-Control-Allow-Origin", "*"); 
          response.setContentType("application/json");
          response.setCharacterEncoding("UTF-8");
          String ruta=request.getRealPath("/");                
	  SAXBuilder builder = new SAXBuilder();
          //Se obtiene la ruta del xml de los usuarios
	  File xmlFile = new File(ruta+"usuarios.xml");
          
          //Se declara un objeto Json.
          JsonObject respo=new JsonObject();
            PrintWriter out = response.getWriter();
            try {
		Document doc = (Document) builder.build(xmlFile);
                Element rootNode = doc.getRootElement();
                //Se declara una lista con los usuarios.
		List list = rootNode.getChildren("NoUser");
                
                //Se guardan el nombre y contraseña recibidos de React
                String name = request.getParameter("username");
                String pass = request.getParameter("password");
                
                //Se declara un boleano para comprobacion
                boolean comp=false;
                
                //Se recorre la lista de usuarios
		for (int i = 0; i < list.size(); i++){
		   Element node = (Element) list.get(i);
                   String nombre = node.getAttributeValue("name");
                   
                   //Se compara el nombre de usario exitente con el recibido de React
		   if(name.equals(nombre)){
                       //Si resultan ser iguales a respo se le asigna una propiedad prueba con un valor falso
                       //El boleano comp se vuelve falso y el ciclo se termina
                       respo.addProperty("prueba", false);
                       comp=false;
                       break;
                   }
                   //Si no se cumple la condicion el boleano comp y la propiedad del Json se vuelven true
                   else {
                       comp=true;
                       respo.addProperty("prueba", true);
                   }
		}
                //Si resulta ser que comp termino por ser verdadero se procede a guardar al nuevo usuario
                if(comp){
                    //Se crea un elemento usuario
                    Element user = new Element("NoUser");
                    
                    //Al elemento usuario se le asignan el numero de usuario, su nombre y su contraseña
                    user.setAttribute("nomUser",""+(list.size()+1));
                    user.setAttribute("name",name);
                    user.setAttribute("pass",pass);
                    
                    //Se agrega el usuario al nodo raiz
                    rootNode.addContent(user);
                    
                    //Se guarda el xml
                    XMLOutputter xmlOutput = new XMLOutputter();
                    xmlOutput.setFormat(Format.getPrettyFormat());
                    FileOutputStream writer = new FileOutputStream(ruta+"usuarios.xml");                
                    xmlOutput.output(doc, writer);
                }
                //Se imprime el Json
                out.println(respo);
	  }
          catch (IOException io) 
          {
		System.out.println(io.getMessage());
	  } 
          catch (JDOMException jdomex) 
          {
		System.out.println(jdomex.getMessage());
	  }    
    }
}