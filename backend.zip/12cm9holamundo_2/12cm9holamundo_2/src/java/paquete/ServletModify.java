package paquete;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

public class ServletModify extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
            String ruta=request.getRealPath("/");
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter(); 
        try
        {
            SAXBuilder builder = new SAXBuilder();
            //Se obtiene la ruta del xml
            File xmlFile = new File(ruta+"cuestionario.xml");
            Document doc = builder.build(xmlFile);
            
            //Se obtiene el nodo raiz
            Element rootNode = doc.getRootElement();
            //Se obtiene una lista con las preguntas del xml
            List list = rootNode.getChildren("pregunta");
            //Se declara un elemento nulo
            Element pregunta = null;

            //Se obtiene el numero de pregunta que se analizara
	    int numPreg = Integer.parseInt(request.getParameter("nomP"));
            
            //Se recorre la lista de preguntas
            for (int i = 0; i < list.size(); i++)
            {
                Element node = (Element) list.get(i);
                //Se obtiene el numero de la pregunta
                int a = Integer.parseInt(node.getAttributeValue("numeroPregunta"));

                //Se asigna la pregunta que necesitamos

                if (a == numPreg)
                {
                    pregunta = node;
                }

            }
        //Obtiene el elemento option
        Element option = pregunta.getChild("option");

        //Hace una lista de las opciones
        List options = option.getChildren("opcion");
        
        //Se hace un formulario con los valores predeterminados de la pregunta original
        out.println("<form method='get' action='ServletModSub'>");
        out.println ("<h2>Modificar la pregunta "+numPreg+"</h2>");
        out.println("<input type='hidden' value='"+numPreg+"' name='numeroPregunta'>");
        out.println("<a>Pregunta</a><input value='"+pregunta.getAttributeValue("pregunta")+"' type='text' size='70' name = 'pregunta'></br>");
        out.println("<a>Pregunta</a><input value='"+pregunta.getAttributeValue("respuesta")+"' type='text' size='70' name = 'respuesta'></br>");
        for (int i = 0; i< options.size(); i++)
        {
            Element op = (Element) options.get(i);
            out.println("<a>Opcion "+(i+1)+" </a><input value = '"+op.getValue()+"' type='text' size='30' name='opcion_"+(i+1)+"'></br>");

        }
        out.println ("<input type='submit'>");
        //El input envia los datos del formulario al Servlet para modificar la pregunta
        out.println ("</form>");
        
        //Se decara un boton para volver al menu
        out.println("<form action='http://localhost:3000/menu'>");
            out.println("<input type='submit' value='Volver'/>");
        out.println("</form>");
        out.println ("</body>");
        out.println ("</html>");
        }
           catch (IOException | JDOMException e)
   {
       e.printStackTrace();
   }
   } 
}
