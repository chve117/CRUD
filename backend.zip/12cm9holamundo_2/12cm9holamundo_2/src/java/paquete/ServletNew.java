package paquete;

import java.io.*;
import java.util.*;
 
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class ServletNew extends HttpServlet{
   
   private boolean isMultipart;
   private String filePath;
   private int maxFileSize = 50 * 1024 * 1024;
   private int maxMemSize = 4 * 1024;
   private File file ;

   @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, java.io.IOException {
      // Check that we have a file upload request
      filePath = request.getRealPath("/"); 
      isMultipart = ServletFileUpload.isMultipartContent(request);
      response.setContentType("text/html");
      java.io.PrintWriter out = response.getWriter( );
      String ruta=request.getRealPath("/");
      SAXBuilder builder = new SAXBuilder();
      File xmlFile = new File(ruta+"cuestionario.xml");
      response.setContentType("text/html;charset=UTF-8");
      String imgtemp="";
      String[] textemp=new String[10];
      if( !isMultipart ) {
         out.println("<html>");
         out.println("<head>");
         out.println("<title>Servlet upload</title>");  
         out.println("</head>");
         out.println("<body>");
         out.println("<p>No se subio el archivo</p>"); 
         out.println("</body>");
         out.println("</html>");
         return;
      }
  
      DiskFileItemFactory factory = new DiskFileItemFactory();
   
      // maximum size that will be stored in memory
      factory.setSizeThreshold(maxMemSize);
   
      // Location to save data that is larger than maxMemSize.
      factory.setRepository(new File(filePath));

      // Create a new file upload handler
      ServletFileUpload upload = new ServletFileUpload(factory);
   
      // maximum file size to be uploaded.
      upload.setSizeMax( maxFileSize );

      try { 
         // Parse the request to get file items.
         List fileItems = upload.parseRequest(request);
	
         // Process the uploaded file items
         Iterator i = fileItems.iterator();
         int text=0;
         Document doc = (Document) builder.build(xmlFile);
         Element rootNode = doc.getRootElement();
         List list = rootNode.getChildren("pregunta");
         Element Pregunta=new Element("pregunta");
         Pregunta.setAttribute("numeroPregunta",""+(list.size()+1));
         while ( i.hasNext () ) {
            FileItem fi = (FileItem)i.next();
            if ( !fi.isFormField () ) {
               // Get the uploaded file parameters
               String fieldName = fi.getFieldName();
               String fileName = fi.getName();
               String contentType = fi.getContentType();
               boolean isInMemory = fi.isInMemory();
               long sizeInBytes = fi.getSize();
            
               // Write the file
               
               if(!fileName.isEmpty()){
                if( fileName.lastIndexOf("\\") >= 0 ) {
                   file = new File( filePath + fileName.substring( fileName.lastIndexOf("\\"))) ;
                } else {
                   file = new File( filePath + fileName.substring(fileName.lastIndexOf("\\")+1)) ;
                }
                fi.write( file );
                //Se carga el archivo multimedia
                imgtemp=fileName;
                out.println("Archivo subido: " + fileName + "<br />");
               }
               else{
                   out.println("Sin documentos</a><br/>");
               }
            }
            else{
                //Se guardan los datos del formulario en un arreglo
                String opcion = fi.getFieldName();
                String value= fi.getString();
                if(!value.isEmpty()){
                    textemp[text]=value;
                    text++;
                }
            }
         }
         //Se crea una nueva pregunta construyendo el xml de la pregunta desde el inicio
         //Se crea un elemeto option
         Element options=new Element("option");
         
         //Se crea un for que recorre el arreglo en donde se guardaron las opciones
         for(int j=2;j<7;j++){
             //Se crea un nodo para las opciones 
             Element node = new Element("opcion");
             node.setText(textemp[j]);
             //Se agregan las opciones al elemento option
             options.addContent(node);
         }
         
         //Se crea un elemento imagen para guardar el archivo multimedia
         Element image=new Element("imagen");
         
         //A la imagen se le asigna el atributo del nombre del archivo y en el texto se le pone un id
         image.setAttribute("image",imgtemp);
         image.setText(""+(list.size()+1));
         
         //Al elemento pregunta se le agregan option e imagen
         Pregunta.addContent(options);
         Pregunta.addContent(image);
         
         //A la pregunta se le asignan los atributos pregunta y respuesta.
         Pregunta.setAttribute("pregunta",textemp[0]);
         Pregunta.setAttribute("respuesta",textemp[1]);
         
         //Al nodo raiz se le agrega la pregunta antes contruida.
         rootNode.addContent(Pregunta);
         
         //se guarda el documento xml
         XMLOutputter xmlOutput = new XMLOutputter();
         xmlOutput.setFormat(Format.getPrettyFormat());
         FileOutputStream writer = new FileOutputStream(ruta+"cuestionario.xml");                
         xmlOutput.output(doc, writer);
         
         //Se crea un boton para volver al menu
         out.println("<form action='http://localhost:3000/menu'>");
            out.println("<input type='submit' value='Volver'/>");
         out.println("</form>");
         writer.flush();
         writer.close();                
         } catch(Exception ex) {
            System.out.println(ex);
         }
    }
     
      
      public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, java.io.IOException 
      {

         throw new ServletException("GET method used with " +
            getClass( ).getName( )+": POST method required.");
      }
   }
