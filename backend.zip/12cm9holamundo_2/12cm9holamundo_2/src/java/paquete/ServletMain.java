package paquete;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;


public class ServletMain extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
            String ruta=request.getRealPath("/");
            SAXBuilder builder = new SAXBuilder();     
            
            //Se obtiene la ruta del xml cuetionario
            File xmlFile = new File(ruta+"cuestionario.xml"); 
            response.addHeader("Access-Control-Allow-Origin", "*"); 
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
            
            //Se declara un objeto Json
            JsonArray respo = new JsonArray();
            try{
                Document doc = builder.build(xmlFile);
                
                //Se obtiene el elemento raiz
                Element root=doc.getRootElement();
                
                //Se obtiene una lista de las pregunas
                List list = root.getChildren("pregunta");
                
                //El ciclo recorre la lista de elementos
                for(int i=0;i<list.size();i++){
                    //Se usa un Json temporal para sacar todas las preguntas junto con sus numeros
                    JsonObject temp = new JsonObject();
                    Element node=(Element)list.get(i);
                    temp.addProperty("pregunta",node.getAttributeValue("pregunta"));
                    temp.addProperty("nomP",node.getAttributeValue("numeroPregunta"));
                    //El Json temporal se guarda en otro Json principal
                    respo.add(temp);
                }
                //Se imprime el Json principal
                out.println(respo);
            } 
            catch (IOException io){
                System.out.println(io.getMessage());
            }
            catch (JDOMException jdomex){
                System.out.println(jdomex.getMessage());
            }

    }
}