package paquete;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;


public class Servletver extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
            String ruta=request.getRealPath("/");
            SAXBuilder builder = new SAXBuilder();     
            File xmlFile = new File(ruta+"usuarios.xml"); 
            response.addHeader("Access-Control-Allow-Origin", "*"); 
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
            JsonArray respo = new JsonArray();
            try{
                Document doc = builder.build(xmlFile);
                Element root=doc.getRootElement();
                List list = root.getChildren("NoUser");
                for(int i=0;i<list.size();i++){
                    JsonObject temp = new JsonObject();
                    Element node=(Element)list.get(i);
                    //out.println("<td>"+node.getAttributeValue("pregunta")+"</td>");
                    temp.addProperty("name",node.getAttributeValue("name"));
                    temp.addProperty("pass",node.getAttributeValue("pass"));
                    //out.println("<td><a href='ServletRead?numeroPregunta="+a+"'>Leer Pregunta</a>|<a href='ServletDelete?numeroPregunta="+a+"'>Borrar Pregunta</a>|<a href='ServletModify?numeroPregunta="+a+"'>Modificar Pregunta</a></td>");
                    respo.add(temp);
                }
                out.println(respo);
            } 
            catch (IOException io){
                System.out.println(io.getMessage());
            }
            catch (JDOMException jdomex){
                System.out.println(jdomex.getMessage());
            }

    }
}