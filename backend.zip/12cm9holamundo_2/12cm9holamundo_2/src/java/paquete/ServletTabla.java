package paquete;

import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

public class ServletTabla extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
          response.addHeader("Access-Control-Allow-Origin", "*"); 
          response.setContentType("application/json");
          response.setCharacterEncoding("UTF-8");
          
          //Se obtiene la ruta actual
          String ruta=request.getRealPath("/");
	  SAXBuilder builder = new SAXBuilder();
          
          //Se obtiene la ruta del xml del cuestionario
	  File xmlFile = new File(ruta+"cuestionario.xml");
          
          //Se declara un objeto Json
          JsonObject respo=new JsonObject();
            PrintWriter out = response.getWriter();
            try {
		Document document = (Document) builder.build(xmlFile);
                //Se obtiene el nodo raiz
		Element rootNode = document.getRootElement();
                
                //Se declara una lista de las preguntas
		List list = rootNode.getChildren("pregunta");
                
                //Se obtiene el numero de pregunta
                int numPreg = Integer.parseInt(request.getParameter("nomP"));
                
                //Se declara un elemento pregunta vacio
                Element pregunta = null;
                
                //Se recorre la lista de preguntas
		for (int i = 0; i < list.size(); i++)
                {
		   Element node = (Element) list.get(i);
		   int a= Integer.parseInt(node.getAttributeValue("numeroPregunta"));
                   //La pregunta se guarda si es igual a la que se pide por el React
                   if(a == numPreg){
                      pregunta = node;
                   }
		}
                //Se le guardan propiedades al Json.
                respo.addProperty("NoPregunta",pregunta.getAttributeValue("numeroPregunta"));
                respo.addProperty("Pregunta",pregunta.getAttributeValue("pregunta"));
                respo.addProperty("Respuesta",pregunta.getAttributeValue("respuesta"));
                //Se obtiene elemento option
                Element options = pregunta.getChild("option");
                //Se hace una lista de opciones
                List opciones = options.getChildren("opcion");
                
                //Recorre todas las opciones
                for(int i=0;i<opciones.size();i++){
                     Element opt = (Element) opciones.get(i);
                     //Se guarda en el Json las opciones
                     respo.addProperty("option"+(i),opt.getValue());
                }
                //Se crea un elemento image que ereda de imagen
                Element image = pregunta.getChild("imagen");
                
                //Se guardan las propiedades del elemento multimedia en el Json
                respo.addProperty("image",image.getValue());
                respo.addProperty("imageName", image.getAttributeValue("image"));
                //Se imprime el Json
                out.println(respo);
	  }
          catch (IOException io) 
          {
		System.out.println(io.getMessage());
	  } 
          catch (JDOMException jdomex) 
          {
		System.out.println(jdomex.getMessage());
	  }    
    }
}