package paquete;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;


public class ServletDelet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
            String ruta=request.getRealPath("/");                
            response.addHeader("Access-Control-Allow-Origin", "*"); 
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();            
            try{
            SAXBuilder builder = new SAXBuilder();
            
            //Se obtiene el xml donde se guardan los ejercicios.
            File xmlFile = new File(ruta+"cuestionario.xml");                
            Document doc = builder.build(xmlFile);
            
            //Se obtiene el nodo raiz del xml
            Element rootNode=doc.getRootElement();
            
            //Se obtiene una lista de preguntas del xml
            List list=rootNode.getChildren("pregunta");
            
            //Se obtiene el numero de preguntas por parte del React
            int numPreg = Integer.parseInt(request.getParameter("nomP"));
            
            //Se declara un elemento vacio
            Element pregunta = null;
            
            //En el siguiente ciclo se recorre la lista de preguntas
            for(int i=0; i < list.size(); i++){
                Element node = (Element) list.get(i);
                int a = Integer.parseInt(node.getAttributeValue("numeroPregunta"));
                //Si el numero de pregunta del elemento temporal es igual a la que envio React
                //Se remueve de la lista la pregunta que indico el elemento temporal
                if(a == numPreg){
                    pregunta = node;
                    list.remove(pregunta);
                }
            }
            
            //Si el tamaño de la lista es mayor o igual que el numero recibido
            //Los elementos siguientes a la pregunta eliminada reajustan su id
            if(list.size()>=numPreg){
                for(int i=0;i<list.size();i++){
                    Element node = (Element) list.get(i);
                    int a = Integer.parseInt(node.getAttributeValue("numeroPregunta"));
                    String temp = Integer.toString(a-1);
                    if(a>numPreg){
                        node.setAttribute("numeroPregunta",temp);
                    }
                }
            }
            XMLOutputter xmlOutput = new XMLOutputter();
            xmlOutput.setFormat(Format.getPrettyFormat());
            FileWriter writer = new FileWriter(ruta+"cuestionario.xml");                
            xmlOutput.output(doc, writer);
            writer.flush();
            writer.close();
            } 
            catch (IOException | JDOMException e) 
            {
            e.printStackTrace();
            }

    }
}