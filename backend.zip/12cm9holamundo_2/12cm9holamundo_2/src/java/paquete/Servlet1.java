package paquete;

import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;

public class Servlet1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
          response.addHeader("Access-Control-Allow-Origin", "*"); 
          response.setContentType("application/json");
          response.setCharacterEncoding("UTF-8");
          
          //Se obtiene la ruta del archivo
          String ruta=request.getRealPath("/");
	  SAXBuilder builder = new SAXBuilder();
          
          //Se obtiene el xml en la que se ubican los usuarios
	  File xmlFile = new File(ruta+"usuarios.xml");
          
          //Se declara un Json que se va a enviar a React
          JsonObject respo=new JsonObject();
            PrintWriter out = response.getWriter();
            try {
		Document document = (Document) builder.build(xmlFile);
                
                //Se obtiene el nodo raiz del xml
		Element rootNode = document.getRootElement();
                
                //Se obtiene la lista de usuarios basandose en el numero de usuario
		List list = rootNode.getChildren("NoUser");
                
                //Se reciben el nombre de usuario y la contraseña introducidos en React
                String name = request.getParameter("username");
                String pass = request.getParameter("password");
                
                //Se usa un ciclo para ver a todos los usuarios registrados
		for (int i = 0; i < list.size(); i++){
                   //Se usa un nodo temporal que guarda el elemento de la lista en que este
		   Element node = (Element) list.get(i);
                   
                   //Del elemento temporal se obtiene el nombre y la contraseña del elemento temporal
                   String nombre = node.getAttributeValue("name");
                   String password = node.getAttributeValue("pass");
                   
                   //Se comparan el usuario y contraseña
                   //Si son iguales el Json se agrega una propiedad al Json con un true ademas de terminar el ciclo.
                   if(name.equals(nombre)&&pass.equals(password)){
                    respo.addProperty("prueba", true);
                    break;
                   }
                   
                   //Si los datos no coinciden con ningun usuario y contraseña la propiedad es false
                   else{
                    respo.addProperty("prueba", false);
                   }
		}
                
                //Se imprime el objeto Json
                out.println(respo);
	  }
          catch (IOException io) 
          {
		System.out.println(io.getMessage());
	  } 
          catch (JDOMException jdomex) 
          {
		System.out.println(jdomex.getMessage());
	  }    
    }
}