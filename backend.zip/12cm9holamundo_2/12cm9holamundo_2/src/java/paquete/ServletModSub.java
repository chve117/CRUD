package paquete;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class ServletModSub extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
            String ruta=request.getRealPath("/");
            //Se obtiene la ruta verdadera
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
        try
        {

            SAXBuilder builder = new SAXBuilder();
            //Se obtiene la ruta del xml del cuestionario
            File xmlFile = new File(ruta+"cuestionario.xml");
            Document doc = builder.build(xmlFile);
            
            //Se obtiene el nodo raiz
            Element rootNode = doc.getRootElement();
            
            //Se obtiene una lista de preguntas guardadas en el xml
            List list = rootNode.getChildren("pregunta");
            //Se declara un elemento vacio
            Element pregunta = null;

            //obtiene el numero de pregunta que se analizara
	    int numPreg = Integer.parseInt(request.getParameter("numeroPregunta"));

            //Se recorre la lista de preguntas
            for (int i = 0; i < list.size(); i++){
                //Se guarda un elemento temporal de la lista
                Element node = (Element) list.get(i);
                //Se obtiene el numero de la pregunta
                int a = Integer.parseInt(node.getAttributeValue("numeroPregunta"));
                //Se asigna la pregunta que necesitamos
                if (a == numPreg)
                {
                    pregunta = node;
                }

            }
            //Al elemento de la pregunta se le reemplaza el atributo pregunta con el recibido de React
            pregunta.setAttribute("pregunta",request.getParameter("pregunta"));
            
            //Se le reemplaza a la pregunta el atributo respuesta con el recibido de react
            pregunta.setAttribute("respuesta",request.getParameter("respuesta"));

        //Obtiene el elemento option
        Element option = pregunta.getChild("option");

        //Se hace una lista con las opciones guardadas en option
        List options = option.getChildren("opcion");
        
        //Se recorre la lista de opciones
        for (int i = 0; i < options.size(); i++)
        {
            //Se reemplazan las opciones con las que se envian desde el React
            Element opcion = (Element) options.get(i);
            opcion.setText(request.getParameter("opcion_"+(i+1)));
        }
        
        //Se guarda el xml
        XMLOutputter xmlOutput = new XMLOutputter();
        xmlOutput.setFormat(Format.getPrettyFormat());
        FileOutputStream writer = new FileOutputStream(ruta+"cuestionario.xml");
        xmlOutput.output (doc, writer);
        writer.flush();
        writer.close();
        out.println("<a>Pregunta modifica con exito<a>");
        
        //Se hace un boton para volver al menu
        out.println("<form action='http://localhost:3000/menu'>");
            out.println("<input type='submit' value='Volver'/>");
         out.println("</form>");
        }
        catch (IOException | JDOMException e)
        {
            e.printStackTrace();
        }

   }
}